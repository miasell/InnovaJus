# LexTech Blog

Blog statico sul diritto delle nuove tecnologie, realizzato in HTML e Tailwind CSS.